import type { Config } from "tailwindcss";
const config: Config = {
  content: ["./app/**/*.{js,ts,jsx,tsx,mdx}", "./components/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      colors: { cream: "#F6F1E8", sand: "#E7D8C5", clay: "#B86F52", olive: "#687052", bark: "#40382F", ink: "#25231F" },
      fontFamily: { display: ["Georgia", "serif"], sans: ["Arial", "sans-serif"] }
    }
  },
  plugins: []
};
export default config;