# House of Bhumi

Premium, earthy e-commerce Phase 1 built with Next.js App Router, Tailwind CSS and Framer Motion-ready architecture.

## Run locally
```bash
npm install
npm run dev
```

## Pages
- `/` Landing page
- `/shop` Shop / collections
- `/product/terra-vase` Product detail template (all product slugs work)
- `/about` About page

## Deploy
Import the repository into Vercel. No environment variables are required for Phase 1.

## Phase 2
Connect cart, checkout, CMS/product data, auth, search, filters, analytics and payments.
