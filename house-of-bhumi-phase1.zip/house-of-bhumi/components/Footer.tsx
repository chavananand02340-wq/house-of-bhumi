import Link from "next/link";
export default function Footer(){
 return <footer className="bg-bark text-cream py-16">
  <div className="container-x grid gap-12 md:grid-cols-3">
   <div><div className="serif text-2xl tracking-[.12em]">HOUSE OF BHUMI</div><p className="mt-4 max-w-xs text-sm leading-7 text-cream/65">Objects for a slower, softer way of living.</p></div>
   <div className="flex gap-12 text-xs tracking-[.16em]"><div className="space-y-4"><Link href="/shop" className="block">SHOP</Link><Link href="/about" className="block">OUR STORY</Link></div><div className="space-y-4"><a href="#" className="block">INSTAGRAM</a><a href="#" className="block">CONTACT</a></div></div>
   <div><p className="text-xs tracking-[.18em]">JOIN THE JOURNAL</p><div className="mt-4 flex border-b border-cream/30 pb-3"><input placeholder="Your email" className="w-full bg-transparent outline-none text-sm placeholder:text-cream/35"/><button className="text-xs tracking-[.12em]">JOIN</button></div></div>
  </div>
  <div className="container-x mt-16 border-t border-cream/10 pt-5 text-[10px] tracking-[.15em] text-cream/40">© 2026 HOUSE OF BHUMI · CRAFTED WITH INTENTION</div>
 </footer>
}