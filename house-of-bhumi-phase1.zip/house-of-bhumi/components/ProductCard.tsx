import Link from "next/link";
import Image from "next/image";
import { Product } from "@/lib/products";
export default function ProductCard({p}:{p:Product}){
 return <Link href={`/product/${p.slug}`} className="group block">
  <div className="relative aspect-[4/5] overflow-hidden bg-sand"><Image src={p.image} alt={p.name} fill className="object-cover transition duration-700 group-hover:scale-105"/><div className="absolute inset-x-0 bottom-0 flex justify-between bg-cream/90 px-4 py-3 translate-y-full transition duration-300 group-hover:translate-y-0 text-[10px] tracking-[.16em]"><span>VIEW PIECE</span><span>↗</span></div></div>
  <div className="flex justify-between gap-4 pt-4"><div><p className="serif text-lg">{p.name}</p><p className="mt-1 text-[10px] tracking-[.16em] text-bark/55">{p.category.toUpperCase()}</p></div><p className="text-sm">{p.price}</p></div>
 </Link>
}