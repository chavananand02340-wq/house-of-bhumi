import Link from "next/link";
export default function Header(){
 return <header className="absolute top-0 left-0 right-0 z-20 text-white">
  <div className="container-x flex h-20 items-center justify-between">
   <Link href="/" className="serif text-xl tracking-[.16em]">HOUSE OF BHUMI</Link>
   <nav className="hidden md:flex items-center gap-10 text-[11px] tracking-[.22em]">
    <Link href="/shop" className="hover:opacity-60 transition">SHOP</Link><Link href="/#story" className="hover:opacity-60 transition">STORY</Link><Link href="/about" className="hover:opacity-60 transition">ABOUT</Link>
   </nav>
   <Link href="/shop" className="text-[11px] tracking-[.22em] border-b border-white/60 pb-1">EXPLORE</Link>
  </div>
 </header>
}