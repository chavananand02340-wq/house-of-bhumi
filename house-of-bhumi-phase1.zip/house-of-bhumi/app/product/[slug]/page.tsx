import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import ProductCard from "@/components/ProductCard";
import Footer from "@/components/Footer";
import { products } from "@/lib/products";

export function generateStaticParams(){ return products.map(p=>({slug:p.slug})); }
export default function ProductPage({params}:{params:{slug:string}}){
 const p=products.find(x=>x.slug===params.slug); if(!p) notFound();
 const related=products.filter(x=>x.slug!==p.slug).slice(0,3);
 return <main className="bg-cream"><header className="border-b border-bark/10"><div className="container-x flex h-20 items-center justify-between"><Link href="/" className="serif text-xl tracking-[.14em]">HOUSE OF BHUMI</Link><Link href="/shop" className="text-[10px] tracking-[.18em]">← SHOP</Link></div></header>
 <div className="container-x py-10 md:py-16"><div className="grid gap-8 md:grid-cols-[1.15fr_.85fr] md:gap-14"><div className="grid grid-cols-2 gap-3"><div className="relative col-span-2 aspect-[4/5] overflow-hidden"><Image src={p.image} alt={p.name} fill priority className="object-cover"/></div><div className="relative aspect-square overflow-hidden"><Image src={p.second} alt={`${p.name} detail`} fill className="object-cover"/></div><div className="relative aspect-square overflow-hidden"><Image src={p.image} alt={`${p.name} in context`} fill className="object-cover"/></div></div>
 <div className="md:sticky md:top-10 md:h-fit"><p className="text-[10px] tracking-[.22em] text-clay">{p.category.toUpperCase()}</p><h1 className="serif mt-3 text-5xl leading-tight">{p.name}</h1><p className="mt-4 text-lg">{p.price}</p><div className="my-8 h-px bg-bark/10"/><p className="text-sm leading-8 text-bark/70">{p.description}</p><div className="mt-8"><p className="text-[10px] tracking-[.18em]">SIZE</p><div className="mt-3 grid grid-cols-3 gap-2">{["SMALL","MEDIUM","LARGE"].map(s=><button key={s} className="border border-bark/20 py-3 text-[10px] tracking-[.15em] hover:border-bark">{s}</button>)}</div></div><button className="mt-8 w-full bg-bark py-5 text-[10px] tracking-[.2em] text-cream transition hover:bg-clay">ADD TO CART — COMING SOON</button><div className="mt-8 space-y-4 border-t border-bark/10 pt-6 text-[11px] tracking-[.08em]"><details><summary className="cursor-pointer">MATERIAL & CARE</summary><p className="mt-3 text-sm leading-6 text-bark/60">Designed for everyday use. Natural variation is part of the character of each piece.</p></details><details><summary className="cursor-pointer">SHIPPING</summary><p className="mt-3 text-sm leading-6 text-bark/60">Shipping and returns will be enabled in Phase 2.</p></details></div></div></div>
 <section className="mt-24 border-t border-bark/10 pt-16"><p className="text-[10px] tracking-[.22em] text-clay">YOU MAY ALSO LIKE</p><div className="mt-10 grid gap-x-5 gap-y-14 sm:grid-cols-2 lg:grid-cols-3">{related.map(x=><ProductCard key={x.slug} p={x}/>)}</div></section></div><Footer/></main>
}