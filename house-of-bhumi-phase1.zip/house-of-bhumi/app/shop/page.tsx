import Link from "next/link";
import ProductCard from "@/components/ProductCard";
import Footer from "@/components/Footer";
import { products } from "@/lib/products";
export default function Shop(){
 return <main className="min-h-screen bg-cream"><header className="border-b border-bark/10"><div className="container-x flex h-20 items-center justify-between"><Link href="/" className="serif text-xl tracking-[.14em]">HOUSE OF BHUMI</Link><Link href="/" className="text-[10px] tracking-[.18em]">HOME</Link></div></header>
 <div className="container-x py-16 md:py-24"><div className="flex flex-col justify-between gap-8 md:flex-row md:items-end"><div><p className="text-[10px] tracking-[.25em] text-clay">THE COLLECTION</p><h1 className="serif mt-3 text-5xl md:text-6xl">Objects for living.</h1></div><p className="max-w-sm text-sm leading-6 text-bark/60">A considered edit of tactile pieces for homes that value warmth over perfection.</p></div>
 <div className="mt-14 flex flex-wrap gap-3 border-y border-bark/10 py-5 text-[10px] tracking-[.16em]"><button className="bg-bark px-4 py-3 text-cream">ALL PIECES</button><button className="px-4 py-3">DECOR</button><button className="px-4 py-3">TEXTILES</button><button className="px-4 py-3">KITCHEN</button><button className="ml-auto px-4 py-3">FILTER +</button></div>
 <div className="mt-10 grid gap-x-5 gap-y-14 sm:grid-cols-2 lg:grid-cols-3">{products.map(p=><ProductCard key={p.slug} p={p}/>)}</div></div><Footer/></main>
}