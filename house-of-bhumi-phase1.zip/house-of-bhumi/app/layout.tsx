import type { Metadata } from "next";
import "./globals.css";
import Link from "next/link";

export const metadata: Metadata = {
  title: "House of Bhumi — Objects with a soul",
  description: "Earthy, considered home and lifestyle pieces made for slow living.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}